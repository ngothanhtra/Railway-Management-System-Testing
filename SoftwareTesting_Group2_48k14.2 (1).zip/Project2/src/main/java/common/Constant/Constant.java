package common.Constant;
import org.openqa.selenium.WebDriver;
public class Constant {
    public static WebDriver WEBDRIVER; //biến toàn cục, dùng chung cho nhiều class
    public static final String RAILWAY_URL = "http://railwayb2.somee.com";
    public static final String USERNAME = "nhom2@gmail.com";
    public static final String PASSWORD = "0987654321";
}